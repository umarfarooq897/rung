import React from "react"; 
const HelpContent =() =>{
    return(
        <>
            
            <div className="page-content">
            	<div className="categories-page">
	                <div className="container">
	                	Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quaerat, maxime blanditiis, id adipisci esse modi cupiditate aperiam magni error natus sed inventore magnam quibusdam nemo sint eius quae neque nisi?
                        <ul>
                            <li>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Laboriosam, blanditiis. Soluta iste numquam modi ipsam expedita accusamus, dolorem nisi itaque?</li>
                            <li>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Laboriosam, blanditiis. Soluta iste numquam modi ipsam expedita</li>
                            <li>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Laboriosam, blanditiis. Soluta iste numquam modi ipsam expedita Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempore non officiis voluptas numquam consectetur eligendi corrupti eaque voluptatibus enim pariatur laboriosam ducimus, dignissimos vitae quos laudantium ex tenetur repellendus qui perspiciatis inventore quod libero. Ducimus ea deleniti voluptatum amet quas deserunt, vero rem eveniet odio sit odit qui repellat! Repellat.</li>
                            <li>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ut voluptatem cum alias hic obcaecati iste soluta. Repudiandae exercitationem officiis nemo voluptatem enim eius et facere, odit aspernatur corrupti magni voluptate.</li>
                            <li>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Molestiae culpa blanditiis, quis dignissimos illum aspernatur iusto similique ad rem ut possimus dolores accusantium corrupti pariatur facilis obcaecati tempore non unde.
                                <ul>
                                    <li>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ratione unde numquam veritatis, ad cum illum.</li>
                                    <li>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ratione unde numquam veritatis, ad cum illum.</li>
                                    <li>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ratione unde numquam veritatis, ad cum illum.</li>
                                </ul>
                            </li>
                            <li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam, eos delectus aliquid corrupti necessitatibus esse!</li>
                            <li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam, eos delectus aliquid corrupti necessitatibus esse!</li>
                            <li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis eum molestias omnis praesentium asperiores unde error necessitatibus, minus possimus aperiam temporibus, fuga illum sequi excepturi qui harum libero similique corrupti.</li>
                            <li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Totam quae dolor cumque alias ipsa possimus deleniti molestiae nihil esse nesciunt soluta, consequatur dolorum eos asperiores debitis impedit iusto voluptas consequuntur deserunt, ducimus consectetur recusandae eum, laudantium officia. Iste maxime omnis distinctio autem, iusto esse doloribus in ipsa, incidunt recusandae adipisci.</li>
                        </ul>
	                </div>
                    {/* <!-- End .container --> */}
                </div>
                {/* <!-- End .categories-page --> */}
			
				
            </div>
            {/* <!-- End .page-content --> */}
        </>
    );
}
export default HelpContent;