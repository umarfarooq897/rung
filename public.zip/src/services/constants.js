export const ADD_TO_CART = "ADD_TO_CART"
export const DECREMENT = "DECREMENT"
export const INCREMENT = "INCREMENT"
export const REMOVE_TO_CART = "REMOVE_TO_CART"