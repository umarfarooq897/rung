import React from "react";
import HeaderContainer from "../container/HeaderContainer";
import Footer2 from "../components/Footer2";
import Signup from "../components/Registeration";
const Register = () =>{
    return(
        <>
            <HeaderContainer/>
            <Signup/>
            <Footer2/>
        </>
    );
}
export default Register;