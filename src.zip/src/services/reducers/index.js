import {combineReducers} from 'redux';
import {cardItem} from './reducer';
export default combineReducers({
        cardItem,
})